## Reference

* https://zhuanlan.zhihu.com/p/24709748
* https://zhuanlan.zhihu.com/p/24863977